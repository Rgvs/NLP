from itertools import izip
actual=open('actual.txt','r')
prediction = open('prediction.txt' ,'r')
tp=fp=fn=tn=0
with open("actual.txt") as textfile1, open("prediction.txt") as textfile2: 
    for x, y in izip(textfile1, textfile2):
        x = x.strip()
        y = y.strip()
	if(x=='ratingpositive' and y=='ratingpositive'):
		tp+=1
	if(x=='ratingnegative' and y=='ratingnegative'):
		tn+=1
	if(x=='ratingpositive' and y=='ratingnegative'):
		fn+=1
	if(y=='ratingpositive' and x=='ratingnegative'):
		fp+=1

accu=float(tp+tn)/float(tp+tn+fp+fn)

print tp
print tn
print fp
print fn
print accu

	
	
