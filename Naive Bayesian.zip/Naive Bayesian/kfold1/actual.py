import operator
outfile = "actual.txt"

fout = open(outfile, "w+")

cleaned=open('kfoldtesting.txt','r')
for line in cleaned:
	delete_list= line.split()
	if(delete_list[0]=='ratingpositive' or delete_list[0]=='ratingnegative'):
		fout.write(delete_list[0])
		fout.write('\n')

