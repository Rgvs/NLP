import math
outfile = "probability of words with labels.txt"

fout = open(outfile, "w+")

cleaned=open('kfoldtraining.txt','r')
probability = open('vocab.txt' ,'r')
count = 0
for line in probability:	
	count+= 1
#print count
probability = open('vocab.txt' ,'r')
matrix = [[0 for x in range(2)] for x in range(count)]

count=0
for line in probability:
	line=line.split()
	word = line[0][2:-2]
	cleaned=open('kfoldtraining.txt','r')
	flag=0
	vocab_word=word
	for line1 in cleaned:
		line1=line1.split()
		if(flag==0):		
			for i in range(0,len(line1)):
				if (line1[i]==vocab_word):
					flag+=1
		if (line1[0] == 'ratingpositive' and flag!=0):						
			matrix[count][0]+=flag
			flag=0			
		if(line1[0] == 'ratingnegative' and flag!=0):
			matrix[count][1]+=flag	
			flag=0
	count+=1

sum_pos=sum_neg=0
for i in range(0, count):                 ##finding count of words in class postive and negative
	sum_pos+=matrix[i][0]
	sum_neg+=matrix[i][1]
print count
print sum_pos
print sum_neg


for i in range(0, count):                         ## smoothing and converting into probability
	matrix[i][0]=(matrix[i][0]+1.0)/float(sum_pos+count)
	matrix[i][1]=(matrix[i][1]+1.0)/float(sum_neg+count)
probability = open('vocab.txt' ,'r')
count=0
for line in probability:
	line=line.split()
	word = line[0][2:-2]
	vocab_word=word
	fout.write(vocab_word)
	fout.write(" ") 
	fout.write(str(-1*math.log(matrix[count][0],2)))
	fout.write(" ")
	fout.write(str(-1*math.log(matrix[count][1],2)))
	fout.write("\n")
	count+=1

cleaned=open('kfoldtraining.txt','r')
pos=neg=0
for line in cleaned:
	l1=line.split()
	if(l1[0]=="ratingpositive"):
		pos+=1
	if(l1[0]=="ratingnegative"):
		neg+=1

check=float(pos)/float(pos+neg)
check+=float(neg)/float(pos+neg)
print check
prob_positive=-1*math.log(float(pos)/float(pos+neg),2)	##probablity of classes
prob_negative=-1*math.log(float(neg)/float(pos+neg),2)

fout.write("Probability of positive class")
fout.write(" ")
fout.write(str(prob_positive))
fout.write("\n")
fout.write("Probability of negative class")
fout.write(" ")
fout.write(str(prob_negative))
fout.write("\n")
fout.write("sum of positive class")
fout.write(" ")
fout.write(str(sum_pos))
fout.write("\n")
fout.write("sum of negative class")
fout.write(" ")
fout.write(str(sum_neg))
fout.write("\n")
fout.write("size of vocabulary")
fout.write(" ")
fout.write(str(count))
fout.write("\n")	
