import operator
outfile = "vocab.txt"

fout = open(outfile, "w+")

cleaned=open('kfoldtraining.txt','r')
l = []
for line in cleaned:
	delete_list= line.split()
	for i in range(0,len(delete_list)):
		l.append(delete_list[i])

cnt=0
print len(l)
wordfreq = []
for w in l:
    wordfreq.append(l.count(w))

#print len(wordfreq)
#print len(set(zip(l, wordfreq)))
ls2=list(set(zip(l, wordfreq)))
ls2.sort(key=operator.itemgetter(1))
for a, b in ls2:
	if(b>1):
		fout.write(str([a,b]))
		fout.write("\n")
