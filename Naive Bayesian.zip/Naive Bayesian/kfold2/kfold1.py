cleaned=open('cleanedfile600.txt','r')
outfile = "kfoldtraining.txt"
outfile1= "kfoldtesting.txt"
fout = open(outfile, "w+")
fout1 = open(outfile1, "w+")
count=0
for line in cleaned:
	delete_list= line.split()
	for k in range(0, len(delete_list)):
		fout.write(delete_list[k])
		fout.write(" ")
	fout.write("\n")
	if(delete_list[0]=='ratingpositive' or delete_list[0]=='ratingnegative'):
		count+=1
	if(count==60):
		break
count=0
cleaned=open('cleanedfile600.txt','r')
for line in cleaned:
	delete_list= line.split()
	if(delete_list[0]=='ratingpositive' or delete_list[0]=='ratingnegative'):
		count+=1
		if count==60:
			continue
	if(count>=60):
		for k in range(0, len(delete_list)):
			fout1.write(delete_list[k])
			fout1.write(" ")
		fout1.write("\n")
	if(count>=120):
		break


cleaned=open('cleanedfile600.txt','r')
count=0
for line in cleaned:
	delete_list= line.split()
	if(delete_list[0]=='ratingpositive' or delete_list[0]=='ratingnegative'):
		count+=1
		if count==120:
			continue
	if(count>=120):
		for k in range(0, len(delete_list)):
			fout.write(delete_list[k])
			fout.write(" ")
		fout.write("\n")
	if(count>600):
		break


	

		
