import math
without_labels=open('testing_without_labels.txt','r')
vocabulary = open('probability of words with labels.txt','r')
outfile=('prediction.txt')
prod_pos=prod_neg=0
sum_pos=28381
sum_neg=10611
count=2992
prob_pos=0.480625840906
prob_neg=1.81942775436
fout = open(outfile, "w+")
for line in without_labels:
	delete_list= line.split()
	if not delete_list:
		if((prod_pos+prob_pos)< (prod_neg+prob_neg)):
			fout.write("ratingpositive")
		else:
			fout.write("ratingnegative")
		fout.write("\n")
		prod_pos=prod_neg=0
		continue		
	for i in range(0,len(delete_list)):
		word= delete_list[i]
		#print word
		#print ('??')
		vocabulary = open('probability of words with labels.txt','r')
		cnt=0
		flag=0		
		for line in vocabulary:
			if(cnt>count):
				break
			cnt+=1			
			vocab=line.split()		
			if(word==vocab[0]):
				print vocab[1]
				prod_pos+=float(vocab[1])
				prod_neg+=float(vocab[2])
				flag=1
				break					
		if flag==0:
			temp=-1*math.log(1.0/float(sum_pos+count+1),2)
			prod_pos+=temp
			temp=-1*math.log(1.0/float(sum_neg+count+1),2)
			prod_neg+=temp

						
'''
	if(delete_list[0]=='ratingpositive' or delete_list[0]=='ratingnegative'):
		fout.write(delete_list[0])
		fout.write('\n')
'''
