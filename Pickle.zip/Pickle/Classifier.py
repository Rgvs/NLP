import operator
import math
import pickle
class Classifier:
    def read_file(self,filename):
        cleaned=open(filename,'r')
        self.train = []
        self.test = []
        self.actual = []
        count=0
        for line in cleaned:
            delete_list= line.split()
            for k in range(0, len(delete_list)):
                if count <60:
                    self.test.append(delete_list[k])
                else:
                    self.train.append(delete_list[k])
            if(delete_list[0]=='ratingpositive' or delete_list[0]=='ratingnegative'):
                count+=1
                if count<60:
                    self.actual.append(delete_list[0])
        #print self.train
    
    def vocabulary(self):
        wordfreq = []
        for w in self.train:
            wordfreq.append(self.train.count(w))
        self.matching=list(set(zip(self.train, wordfreq)))
        self.matching.sort(key=operator.itemgetter(1))
        self.match=[]
        for a,b in self.matching:
            if b>1 and a!= 'ratingpositive' and a!= 'ratingnegative' :
                self.match.append([a,b])
        self.matching=self.match
        #print len(self.matching)
    
    def counting(self):#prob_of_word_with labels
        self.matrix = [[0 for x in range(2)] for x in range(len(self.matching))]
        
        count=0
        for line in self.matching:
            flag=0
            vocab_word=line[0]
            for line1 in self.train:
                
                if (line1==vocab_word):
                    flag+=1
                if (line1 == 'ratingpositive' and flag!=0):
                    self.matrix[count][0]+=flag
                    flag=0
                if(line1 == 'ratingnegative' and flag!=0):
                    self.matrix[count][1]+=flag	
                    flag=0
            count+=1
        #print self.matrix
        sum_pos=sum_neg=0
        for i in range(0, count):                 ##finding count of words in class postive and negative
            sum_pos+=self.matrix[i][0]
            sum_neg+=self.matrix[i][1]
        #print count
        #print sum_pos
        #print sum_neg
        for i in range(0, count):                         ## smoothing and converting into probability
            self.matrix[i][0]=-1*math.log( ( (self.matrix[i][0]+1.0)/float(sum_pos+count) ), 2)
            self.matrix[i][1]=-1*math.log( ( (self.matrix[i][1]+1.0)/float(sum_neg+count) ), 2)
        #print self.matrix
        
        pos=self.train.count("ratingpositive")
        neg=self.train.count("ratingnegative")
        
        prob_positive=-1*math.log(float(pos)/float(pos+neg),2)  ##probablity of classes
        prob_negative=-1*math.log(float(neg)/float(pos+neg),2)
        #print "Probability of negative class",prob_negative
        #print "Probability of positive class",prob_positive

if __name__ == '__main__':
    nbc= Classifier()
    nbc.read_file("cleanedfile600.txt")
    nbc.vocabulary()
    nbc.counting()
    pickle.dump(nbc,open("model.p","wb"))
